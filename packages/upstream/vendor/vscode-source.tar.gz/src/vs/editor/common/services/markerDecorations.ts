/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/

import { ITextModel, IModelDecoration } from '../model.js';
import { createDecorator } from '../../../platform/instantiation/common/instantiation.js';
import { IMarker } from '../../../platform/markers/common/markers.js';
import { Event } from '../../../base/common/event.js';
import { Range } from '../core/range.js';
import { URI } from '../../../base/common/uri.js';
import { IDisposable } from '../../../base/common/lifecycle.js';

export const IMarkerDecorationsService = createDecorator<IMarkerDecorationsService>('markerDecorationsService');

export interface IMarkerLimit {
	/**
	 * Are the marker sources (ie. diagnostics) for a model truncated?
	 */
	readonly isMarkersSourceTruncated: boolean;
	/**
	 * Are the marker decorations for a model truncated?
	 */
	readonly isMarkersTruncated: number | undefined;
}

export interface IMarkerDecorationsService {
	readonly _serviceBrand: undefined;

	readonly onDidChangeMarker: Event<ITextModel>;

	/**
	 * Fires when diagnostics truncation state changes or when the marker limit exceeded state changes.
	 */
	readonly onDidChangeMarkerLimit: Event<ITextModel>;

	getMarker(uri: URI, decoration: IModelDecoration): IMarker | null;

	getLiveMarkers(uri: URI): [Range, IMarker][];

	/**
	 * Returns the marker limit state for a model.
	 */
	getMarkerLimits(uri: URI): IMarkerLimit | undefined;

	addMarkerSuppression(uri: URI, range: Range): IDisposable;
}
